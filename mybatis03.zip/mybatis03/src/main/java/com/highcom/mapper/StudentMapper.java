package com.highcom.mapper;

import com.highcom.po.Student;

import java.util.List;

public interface StudentMapper {
    public List<Student> findStudents();
}
